twelisis
--------

This package aims at making the extaction tweets from twitter abstract.

You can directly use this,simply do:
(Its better to save passwords in a different file.)

>>>import twelisis as t
>>>t.extract_tweets_for_tag(tag_name,password_file_name)
>>>t.extract_sentiment(output_file_name)


