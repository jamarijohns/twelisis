from setuptools import setup

setup(name='twelisis',
      version='0.1',
      description='Extracting Tweets from twitter and analysing them',
      url='http://github.com/yagamiash/Twelisis',
      author='Ashik Poovanna',
      author_email='ashobot@gmail.com',
      packages=['twelisis'],
      zip_safe=False)
